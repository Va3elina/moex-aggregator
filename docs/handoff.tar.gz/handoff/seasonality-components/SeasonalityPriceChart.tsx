import { useRef, useMemo, useState, useLayoutEffect } from 'react';
import ChartNavigator from '../ChartNavigator';
import type { PriceChartResponse } from '../../services/api';
import { CHART_COLORS, CROSSHAIR, PADDING, cssVar, ANIMATION } from '../../config/chartTheme';
import { ChartGrid, ChartCrosshair, ChartDot, ChartDateLabel, ChartTooltip, TooltipRow, ChartYAxis, ChartXAxis, ChartMarker } from '../chart';
import { easeOutCubic, morphPts, ptsToPath } from '../../utils/chartAnimation';

interface TooltipState {
  x: number;
  y: number;
  priceDate?: string;
  priceClose?: number;
  priceAdj?: number;
}

interface SeasonalityPriceChartProps {
  priceData: PriceChartResponse;
  priceNavRange: [number, number] | null;
  setPriceNavRange: (range: [number, number] | null) => void;
  tooltip: TooltipState | null;
  setTooltip: (t: TooltipState | null) => void;
  chartHeight: number;
}

export default function SeasonalityPriceChart({
  priceData,
  priceNavRange,
  setPriceNavRange,
  tooltip,
  setTooltip,
  chartHeight,
}: SeasonalityPriceChartProps) {
  const divHoverRef = useRef(false);

  // Анимация путей: reveal на первом рендере, морф при смене периода,
  // мгновенное обновление при drag'е навигатора (priceData === prev).
  const [revealed, setRevealed] = useState(false);
  const [animRawPath, setAnimRawPath] = useState('');
  const [animAdjPath, setAnimAdjPath] = useState('');
  const prevRawRef = useRef<{ x: number; y: number }[]>([]);
  const prevAdjRef = useRef<{ x: number; y: number }[]>([]);
  const currRawRef = useRef<{ x: number; y: number }[]>([]);
  const currAdjRef = useRef<{ x: number; y: number }[]>([]);
  const animRef = useRef<number | null>(null);
  const isFirstRef = useRef(true);
  const prevPriceDataRef = useRef(priceData);

  const allPricePoints = priceData.data;
  const priceDividends = priceData.dividends;

  // Navigator data format
  const priceNavData = useMemo(() =>
    allPricePoints.map(p => ({ time: p.date, value: p.close })),
    [allPricePoints]);

  // Display points (filtered by navigator)
  const pricePoints = useMemo(() => {
    if (!priceNavRange) return allPricePoints;
    return allPricePoints.slice(priceNavRange[0], priceNavRange[1] + 1);
  }, [allPricePoints, priceNavRange]);

  const priceMinMax = useMemo(() => {
    if (pricePoints.length === 0) return { min: 0, max: 1 };
    const allVals = pricePoints.flatMap(p => [p.close, p.adjusted]);
    const min = Math.min(...allVals);
    const max = Math.max(...allVals);
    const range = max - min || 1;
    return { min: min - range * 0.05, max: max + range * 0.05 };
  }, [pricePoints]);

  if (pricePoints.length === 0) {
    return (
      <div className="flex items-center justify-center" style={{ height: chartHeight, color: 'var(--text-muted)' }}>Нет данных</div>
    );
  }

  // Padding from CSS tokens (with fallback)
  const PL = cssVar('--chart-pad-left', PADDING.left), PR = cssVar('--chart-pad-right-single', PADDING.rightSingle), PT = PADDING.top, PB = 60;
  const hasAdj = pricePoints.some(p => p.close !== p.adjusted);
  const scX = (i: number) => (i / Math.max(pricePoints.length - 1, 1));
  const scY = (v: number) => 1 - (v - priceMinMax.min) / (priceMinMax.max - priceMinMax.min);

  // Таргет в координатах viewBox (0..1000, 0..500) для обоих линий.
  const targetRaw = useMemo(
    () => pricePoints.map((p, i) => ({ x: scX(i) * 1000, y: scY(p.close) * 500 })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pricePoints, priceMinMax]
  );
  const targetAdj = useMemo(
    () => pricePoints.map((p, i) => ({ x: scX(i) * 1000, y: scY(p.adjusted) * 500 })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pricePoints, priceMinMax]
  );

  // Анимация линий — морф на ЛЮБЫЕ изменения (период, тикер, навигатор):
  // 1) Первый рендер → CSS-reveal + instant set paths
  // 2) Смена priceData (период / тикер) → длинный морф 700ms (заметная смена)
  // 3) Только диапазон навигатора изменился → короткий морф 220ms (drag-friendly)
  useLayoutEffect(() => {
    if (!targetRaw.length) { setAnimRawPath(''); setAnimAdjPath(''); return; }
    if (animRef.current) cancelAnimationFrame(animRef.current);

    const priceDataChanged = prevPriceDataRef.current !== priceData;
    prevPriceDataRef.current = priceData;

    // Первый рендер: мгновенно + запуск CSS-reveal
    if (isFirstRef.current || prevRawRef.current.length === 0) {
      isFirstRef.current = false;
      prevRawRef.current = targetRaw;
      prevAdjRef.current = targetAdj;
      currRawRef.current = [];
      currAdjRef.current = [];
      setAnimRawPath(ptsToPath(targetRaw));
      setAnimAdjPath(ptsToPath(targetAdj));
      if (!revealed) setRevealed(true);
      return;
    }

    // Морф: длинная анимация для смены priceData (используем общую
    // ANIMATION.duration как в SimpleChart / OI / Buffett — единый «ритм»
    // через все графики проекта), короткая для drag навигатора.
    const fromRaw = currRawRef.current.length > 0 ? currRawRef.current : prevRawRef.current;
    const fromAdj = currAdjRef.current.length > 0 ? currAdjRef.current : prevAdjRef.current;
    const DURATION = priceDataChanged ? ANIMATION.morphDuration : 220;
    let start: number | null = null;

    const animate = (ts: number) => {
      if (!start) start = ts;
      const t = easeOutCubic(Math.min((ts - start) / DURATION, 1));
      const interpRaw = morphPts(fromRaw, targetRaw, t);
      const interpAdj = morphPts(fromAdj, targetAdj, t);
      currRawRef.current = interpRaw;
      currAdjRef.current = interpAdj;
      setAnimRawPath(ptsToPath(interpRaw));
      setAnimAdjPath(ptsToPath(interpAdj));
      if (t < 1) {
        animRef.current = requestAnimationFrame(animate);
      } else {
        prevRawRef.current = targetRaw;
        prevAdjRef.current = targetAdj;
        currRawRef.current = [];
        currAdjRef.current = [];
      }
    };
    animRef.current = requestAnimationFrame(animate);

    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetRaw, targetAdj, priceData]);
  const yTicks = Array.from({ length: 5 }, (_, i) => {
    const val = priceMinMax.min + ((priceMinMax.max - priceMinMax.min) * i) / 4;
    return { value: val, pct: scY(val) * 100 };
  });
  const xTicks = (() => {
    const count = Math.min(7, pricePoints.length);
    return Array.from({ length: count }, (_, i) => {
      const idx = Math.floor((i / Math.max(count - 1, 1)) * (pricePoints.length - 1));
      return { label: pricePoints[idx].date.slice(5), pct: scX(idx) * 100 };
    });
  })();
  // Visible dividends
  const visibleDivs = priceDividends.filter(d => {
    return pricePoints.some(p => p.date === d.date);
  }).map(d => {
    const idx = pricePoints.findIndex(p => p.date === d.date);
    return { ...d, idx, pct: scX(idx) * 100 };
  });

  return (
    <div>
      {/* Legend centered */}
      <div className="flex justify-center gap-5 text-sm mb-3">
        <span className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.accent }} />
          <span className="text-theme-primary font-medium">Цена</span>
        </span>
        {hasAdj && (
          <span className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.adjusted }} />
            <span className="text-theme-primary font-medium">Без дивидендных гэпов</span>
          </span>
        )}
      </div>

      {/* Floating date label */}
      {tooltip?.priceDate ? (
        <ChartDateLabel date={tooltip.priceDate} x={tooltip.x} />
      ) : (
        <div style={{ height: 22 }} />
      )}

      {/* Chart area — chart-reveal класс активируется после первого рендера */}
      <div className={`relative cursor-crosshair ${revealed ? 'chart-reveal' : ''}`} style={{ aspectRatio: '2.4', minHeight: 280, maxHeight: 550 }}
        onMouseMove={(e) => {
          if (divHoverRef.current) return;
          const rect = e.currentTarget.getBoundingClientRect();
          if (pricePoints.length === 0) return;
          const chartAreaW = rect.width - PL - PR;
          const mx = e.clientX - rect.left - PL;
          if (mx < 0 || mx > chartAreaW) { setTooltip(null); return; }
          const idx = Math.round((mx / chartAreaW) * (pricePoints.length - 1));
          const ci = Math.max(0, Math.min(idx, pricePoints.length - 1));
          const p = pricePoints[ci];
          setTooltip({
            x: PL + (ci / Math.max(pricePoints.length - 1, 1)) * chartAreaW,
            y: e.clientY - rect.top,
            priceDate: p.date, priceClose: p.close, priceAdj: p.adjusted,
          });
        }}
        onMouseLeave={() => { divHoverRef.current = false; setTooltip(null); }}
      >
        {/* SVG */}
        <div className="absolute" style={{ left: PL, right: PR, top: PT, bottom: PB }}>
          <svg viewBox={`0 0 1000 500`} preserveAspectRatio="none" width="100%" height="100%">
            {/* Grid */}
            <ChartGrid yTicks={yTicks} />
            {/* Raw price — путь анимируется через animRawPath */}
            <path d={animRawPath} fill="none" stroke={CHART_COLORS.accent} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />
            {/* Adjusted — dashed линия */}
            {hasAdj && (
              <path d={animAdjPath} fill="none" stroke={CHART_COLORS.adjusted} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="6,3" />
            )}
            {/* Crosshair + Dot */}
            {tooltip?.priceDate && (() => {
              const idx = pricePoints.findIndex(p => p.date === tooltip.priceDate);
              if (idx < 0) return null;
              const cx = scX(idx) * 1000;
              const cy = scY(pricePoints[idx].close) * 500;
              return (
                <>
                  <ChartCrosshair x={cx} color={CROSSHAIR.accentColor} dashArray={CROSSHAIR.accentDashArray} opacity={CROSSHAIR.accentOpacity} />
                  <ChartDot x={cx} y={cy} color={CHART_COLORS.accent} />
                </>
              );
            })()}
          </svg>
        </div>

        {/* Y labels */}
        <ChartYAxis ticks={yTicks} side="right" format={(v) => v.toFixed(0)} padTop={PT} padBottom={PB} />

        {/* X labels */}
        <ChartXAxis labels={xTicks.map(t => t.label)} padLeft={PL} padRight={PR} />

        {/* Dividend circles at bottom */}
        <div className="absolute" style={{ left: PL, right: PR, bottom: PB - 14 }}>
          {visibleDivs.map((d, i) => (
            <ChartMarker
              key={i}
              label="Д"
              xPct={d.pct}
              guideHeight={`calc(100% - ${PB + 14}px)`}
              onHover={() => { divHoverRef.current = true; setTooltip(null); }}
              onLeave={() => { divHoverRef.current = false; }}
            >
              <div className="text-[11px] font-medium text-theme-primary">{d.value} ₽ — {d.date}</div>
            </ChartMarker>
          ))}
        </div>

        {/* Value tooltip */}
        {tooltip?.priceDate && (
          <ChartTooltip x={tooltip.x} y={tooltip.y}>
            <TooltipRow color={CHART_COLORS.accent} label="Цена" value={`${tooltip.priceClose?.toFixed(2)} ₽`} />
            {tooltip.priceAdj !== tooltip.priceClose && (
              <TooltipRow color={CHART_COLORS.adjusted} label="Без гэпов" value={`${tooltip.priceAdj?.toFixed(2)} ₽`} />
            )}
          </ChartTooltip>
        )}
      </div>

      {/* Navigator */}
      <ChartNavigator
        data={priceNavData}
        onChange={(s, e) => setPriceNavRange([s, e])}
        color={CHART_COLORS.accent}
      />
    </div>
  );
}
